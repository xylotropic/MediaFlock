// Uses the pinned upstream inline-worker build, with the reviewed timestamp wrapper.
import { build } from "esbuild";
import { inlineWorkerPlugin } from "./esbuild/inlined-workers.js";
await build({
  entryPoints: ["packages/aac-encoder/src/index.ts"],
  outfile: "packages/aac-encoder/dist/bundles/mediabunny-aac-encoder.mjs",
  bundle: true, target: "es2021", format: "esm", external: ["mediabunny"],
  legalComments: "none",
  banner: {js: "/*! Copyright (c) 2026-present, Vanilagy and contributors. Mozilla Public License 2.0. See LICENSE. */"},
  plugins: [inlineWorkerPlugin({define: {"import.meta.url": '\"\"'}, legalComments: "none"})],
});
